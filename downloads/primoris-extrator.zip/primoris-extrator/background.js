// Primoris Extrator — abre o painel e lembra qual aba estava ativa
chrome.action.onClicked.addListener(async (tab) => {
  const dashUrl = chrome.runtime.getURL("dashboard.html");
  const isDash = tab && tab.url && tab.url.startsWith(dashUrl);
  const target = !isDash && tab ? tab.id : "";

  const existing = await chrome.tabs.query({ url: dashUrl + "*" });
  if (existing.length) {
    const d = existing[0];
    await chrome.tabs.update(d.id, { active: true });
    await chrome.windows.update(d.windowId, { focused: true });
    if (target) chrome.runtime.sendMessage({ type: "primoris:setTab", tabId: target }).catch(() => {});
    return;
  }
  chrome.tabs.create({ url: dashUrl + (target ? "?tab=" + target : "") });
});
