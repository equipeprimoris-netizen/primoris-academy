/* Sistema Primoris — Extrator de Empresas (painel da extensão) */
"use strict";

// ---------------------------------------------------------------------------
// Estado
// ---------------------------------------------------------------------------
const $ = (id) => document.getElementById(id);
const STATUS_OPTS = ["Novo", "Contatado", "Respondeu", "Negociando", "Fechado", "Sem interesse"];

const MAPS_COLUMNS = [
  { key: "nome", label: "Nome" },
  { key: "categoria", label: "Categoria" },
  { key: "telefone", label: "Telefone" },
  { key: "whatsapp", label: "WhatsApp" },
  { key: "site", label: "Site" },
  { key: "email", label: "Email" },
  { key: "endereco", label: "Endereço" },
  { key: "nota", label: "Nota" },
  { key: "avaliacoes", label: "Avaliações" },
  { key: "nicho", label: "Nicho" },
  { key: "cidade", label: "Cidade" },
  { key: "status", label: "Status" },
  { key: "link", label: "Link Maps" },
];

const state = {
  rows: [],
  columns: [],          // [{key,label,visible}]
  tabId: null,
  mode: null,           // 'maps' | 'generic'
  country: "all",
  scrolls: 0,
  startedAt: null,
  scrolling: false,
  paginating: false,
  enriching: false,
  queueRunning: false,
  queueStop: false,
  focus: { list: [], i: 0 },
};

// ---------------------------------------------------------------------------
// Utilidades
// ---------------------------------------------------------------------------
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
function randDelay() {
  let a = Math.max(1, Number($("minDelay").value) || 1);
  let b = Math.max(1, Number($("maxDelay").value) || a);
  if (b < a) [a, b] = [b, a];
  return (a + Math.random() * (b - a)) * 1000;
}
function setStatus(msg, kind = "") {
  const el = $("status");
  el.textContent = msg;
  el.className = "status" + (kind ? " " + kind : "");
}
function toast(msg) {
  const t = document.createElement("div");
  t.className = "toast";
  t.textContent = msg;
  document.body.appendChild(t);
  setTimeout(() => t.remove(), 2200);
}
function progress(done, total) {
  if (!total) { $("progressWrap").style.display = "none"; return; }
  $("progressWrap").style.display = "";
  $("progressBar").style.width = Math.round((done / total) * 100) + "%";
}
const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const slug = (s) => String(s).normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase().replace(/[^a-z0-9]+/g, "_").replace(/^_|_$/g, "") || "col";

function parseQuery(q) {
  q = (q || "").replace(/\+/g, " ").trim();
  const m = q.match(/^(.*)\s+(?:em|in|en|na|no|near|perto de)\s+(.+)$/i);
  if (m) return { nicho: m[1].trim(), cidade: m[2].trim() };
  return { nicho: q, cidade: "" };
}
function queryFromMapsUrl(url) {
  try {
    const m = url.match(/\/maps\/search\/([^/@?]+)/);
    if (m) return decodeURIComponent(m[1].replace(/\+/g, " "));
  } catch (_) {}
  return "";
}

// País
function isBR(r) {
  const tel = String(r.telefone || "").trim();
  if (tel.startsWith("+55")) return true;
  if (tel.startsWith("+")) return false;
  const end = String(r.endereco || "");
  if (/\bBrasil\b|\bBrazil\b/i.test(end) || /\b\d{5}-\d{3}\b/.test(end) || /\s-\s[A-Z]{2}\b/.test(end)) return true;
  if (/\b\d{4}-\d{3}\b/.test(end) || /Portugal|España|Spain|USA|United States|Argentina|Chile|Mexico|México|Colombia|Paraguay|Uruguay|Italia|Italy|France|Deutschland|UK|United Kingdom/i.test(end)) return false;
  const digits = tel.replace(/\D/g, "");
  if (digits.length === 10 || digits.length === 11) return true;
  if (digits.length) return false;
  return true;
}

// WhatsApp
function waNumber(r) {
  const raw = String(r.telefone || "").trim();
  let d = raw.replace(/\D/g, "");
  if (!d) return "";
  if (raw.startsWith("+")) return d.length >= 8 ? d : "";
  if (d.startsWith("0")) d = d.replace(/^0+/, "");
  if (isBR(r)) {
    if (d.length === 10 || d.length === 11) d = "55" + d;
    if (!(d.startsWith("55") && (d.length === 12 || d.length === 13))) return "";
    return d;
  }
  return d.length >= 8 ? d : "";
}
function fillTemplate(r) {
  const t = $("msgTemplate").value || "";
  return t
    .replace(/\{nome\}/gi, r.nome || "")
    .replace(/\{cidade\}/gi, r.cidade || "")
    .replace(/\{nicho\}/gi, r.nicho || "")
    .replace(/\{categoria\}/gi, r.categoria || "");
}
function waLink(r) {
  const n = waNumber(r);
  if (!n) return "";
  const msg = fillTemplate(r);
  return "https://wa.me/" + n + (msg ? "?text=" + encodeURIComponent(msg) : "");
}

function rowKey(r) {
  if (r.link) {
    const m = r.link.match(/!1s([^!?]+)/);
    if (m) return "p:" + m[1];
    return "l:" + r.link.split("?")[0];
  }
  if (r.nome) return "n:" + slug(r.nome) + "|" + slug(r.endereco || "");
  return "g:" + JSON.stringify(r._cells || r);
}

// ---------------------------------------------------------------------------
// Persistência
// ---------------------------------------------------------------------------
let saveTimer = null;
function save() {
  clearTimeout(saveTimer);
  saveTimer = setTimeout(() => {
    chrome.storage.local.set({
      primoris_rows: state.rows,
      primoris_columns: state.columns,
      primoris_settings: {
        minDelay: $("minDelay").value,
        maxDelay: $("maxDelay").value,
        msgTemplate: $("msgTemplate").value,
        queueInput: $("queueInput").value,
        queueScrolls: $("queueScrolls").value,
        autoComplete: $("autoComplete").checked,
        focusAutoStatus: $("focusAutoStatus").checked,
      },
    });
  }, 300);
}
async function load() {
  const d = await chrome.storage.local.get(["primoris_rows", "primoris_columns", "primoris_settings"]);
  state.rows = Array.isArray(d.primoris_rows) ? d.primoris_rows : [];
  state.columns = Array.isArray(d.primoris_columns) ? d.primoris_columns : [];
  const s = d.primoris_settings || {};
  if (s.minDelay) $("minDelay").value = s.minDelay;
  if (s.maxDelay) $("maxDelay").value = s.maxDelay;
  if (s.msgTemplate) $("msgTemplate").value = s.msgTemplate;
  if (s.queueInput) $("queueInput").value = s.queueInput;
  if (s.queueScrolls) $("queueScrolls").value = s.queueScrolls;
  if (typeof s.autoComplete === "boolean") $("autoComplete").checked = s.autoComplete;
  if (typeof s.focusAutoStatus === "boolean") $("focusAutoStatus").checked = s.focusAutoStatus;
}

// ---------------------------------------------------------------------------
// Colunas
// ---------------------------------------------------------------------------
function ensureColumns(keysWithLabels) {
  let changed = false;
  for (const { key, label } of keysWithLabels) {
    if (!state.columns.find((c) => c.key === key)) {
      state.columns.push({ key, label, visible: true });
      changed = true;
    }
  }
  if (changed) renderColumnManager();
}
function visibleColumns() {
  return state.columns.filter((c) => c.visible);
}
function renderColumnManager() {
  const box = $("columnList");
  box.innerHTML = "";
  $("columnManager").style.display = state.columns.length ? "" : "none";
  state.columns.forEach((c) => {
    const chip = document.createElement("label");
    chip.className = "col-chip";
    const cb = document.createElement("input");
    cb.type = "checkbox";
    cb.checked = c.visible;
    cb.addEventListener("change", () => { c.visible = cb.checked; save(); renderTable(); });
    const name = document.createElement("span");
    name.className = "col-name";
    name.textContent = c.label;
    name.title = "Clique pra renomear";
    name.addEventListener("click", (e) => {
      e.preventDefault();
      const inp = document.createElement("input");
      inp.type = "text";
      inp.className = "col-rename";
      inp.value = c.label;
      name.replaceWith(inp);
      inp.focus();
      inp.select();
      const done = () => {
        c.label = inp.value.trim() || c.label;
        save();
        renderColumnManager();
        renderTable();
      };
      inp.addEventListener("blur", done);
      inp.addEventListener("keydown", (ev) => { if (ev.key === "Enter") inp.blur(); if (ev.key === "Escape") { inp.value = c.label; inp.blur(); } });
    });
    chip.append(cb, name);
    box.appendChild(chip);
  });
}

// ---------------------------------------------------------------------------
// Filtros e tabela
// ---------------------------------------------------------------------------
function filteredRows(ignoreCountry = false) {
  const st = $("filterStatus").value;
  const ni = $("filterNicho").value;
  const ci = $("filterCidade").value;
  return state.rows.filter((r) => {
    if (st !== "all" && (r.status || "Novo") !== st) return false;
    if (ni !== "all" && (r.nicho || "") !== ni) return false;
    if (ci !== "all" && (r.cidade || "") !== ci) return false;
    if (!ignoreCountry && state.country !== "all") {
      const br = isBR(r);
      if (state.country === "BR" && !br) return false;
      if (state.country === "INTL" && br) return false;
    }
    return true;
  });
}
function fillSelect(sel, label, values) {
  const cur = sel.value;
  sel.innerHTML = `<option value="all">${label}</option>` + values.map((v) => `<option value="${esc(v)}">${esc(v || "(vazio)")}</option>`).join("");
  sel.value = values.includes(cur) ? cur : "all";
}
function refreshFilters() {
  const has = state.rows.length > 0;
  $("filtersRow").style.display = has ? "" : "none";
  const uniq = (k) => [...new Set(state.rows.map((r) => r[k] || ""))].filter(Boolean).sort((a, b) => a.localeCompare(b, "pt-BR"));
  fillSelect($("filterStatus"), "Status: Todos", STATUS_OPTS);
  fillSelect($("filterNicho"), "Nicho: Todos", uniq("nicho"));
  fillSelect($("filterCidade"), "Cidade: Todas", uniq("cidade"));
}

function cellValue(r, key) {
  if (key === "whatsapp") return waLink(r);
  if (key === "status") return r.status || "Novo";
  return r[key] ?? "";
}

function renderTable() {
  const cols = visibleColumns();
  $("theadRow").innerHTML = cols.map((c) => `<th>${esc(c.label)}</th>`).join("");
  const rows = filteredRows();
  const tb = $("tbody");
  if (!rows.length) {
    tb.innerHTML = `<tr class="empty-row"><td colspan="${Math.max(1, cols.length)}">Nenhuma empresa coletada ainda. Abra uma busca no Google Maps e clique em "Usar aba atual".</td></tr>`;
  } else {
    const html = [];
    for (const r of rows) {
      const id = esc(r._id);
      html.push(`<tr data-id="${id}">` + cols.map((c) => {
        const v = cellValue(r, c.key);
        if (c.key === "status") {
          return `<td><select data-status="${id}">${STATUS_OPTS.map((o) => `<option${o === v ? " selected" : ""}>${o}</option>`).join("")}</select></td>`;
        }
        if (c.key === "whatsapp") {
          return v ? `<td><a class="wa-link" href="${esc(v)}" target="_blank" rel="noopener">💬 Abrir</a></td>` : `<td class="muted">—</td>`;
        }
        if ((c.key === "site" || c.key === "link") && v) {
          const label = c.key === "link" ? "Ver no Maps" : String(v).replace(/^https?:\/\/(www\.)?/, "").replace(/\/$/, "");
          return `<td><a href="${esc(v)}" target="_blank" rel="noopener">${esc(label)}</a></td>`;
        }
        if (c.key === "email" && v) {
          return `<td>${String(v).split(/[,;]\s*/).map((e) => `<a href="mailto:${esc(e)}">${esc(e)}</a>`).join("<br>")}</td>`;
        }
        return `<td>${esc(v)}</td>`;
      }).join("") + "</tr>");
    }
    tb.innerHTML = html.join("");
  }
  // contadores
  const base = filteredRows(true);
  const br = base.filter(isBR).length;
  $("countAll").textContent = base.length;
  $("countBR").textContent = br;
  $("countIntl").textContent = base.length - br;
  $("statRows").textContent = state.rows.length;
  $("statTel").textContent = state.rows.filter((r) => r.telefone).length;
  $("statSite").textContent = state.rows.filter((r) => r.site).length;
  $("statEmail").textContent = state.rows.filter((r) => r.email).length;
  $("statScrolls").textContent = state.scrolls;
  $("btnFocusMode").style.display = state.rows.length ? "" : "none";
}

function rerender() {
  refreshFilters();
  renderTable();
  save();
}

// ---------------------------------------------------------------------------
// Inserção de linhas
// ---------------------------------------------------------------------------
function addRows(list, extra = {}) {
  const index = new Map(state.rows.map((r) => [r._id, r]));
  let added = 0;
  for (const raw of list) {
    const r = { ...raw };
    for (const [k, v] of Object.entries(extra)) if (v && !r[k]) r[k] = v;
    const id = rowKey(r);
    const prev = index.get(id);
    if (prev) {
      for (const [k, v] of Object.entries(r)) if (v && !prev[k]) prev[k] = v;
      continue;
    }
    r._id = id;
    r.status = r.status || "Novo";
    state.rows.push(r);
    index.set(id, r);
    added++;
  }
  return added;
}

// ---------------------------------------------------------------------------
// Funções injetadas na página (rodam DENTRO da aba alvo)
// ---------------------------------------------------------------------------
function pageMapsCollect() {
  const clean = (s) => String(s || "").replace(/[-]/g, "").replace(/\s+/g, " ").trim();
  const HOURS = /\b(Aberto|Fechado|Abre|Fecha|Open|Closed|Opens|Closes|Abierto|Cerrado|24 horas|24 hours|Temporariamente|Temporarily)\b/i;
  const PHONE = /(\+?\(?\d[\d\s().-]{7,}\d)/;
  const out = [];
  const seen = new Set();
  document.querySelectorAll('a[href*="/maps/place/"]').forEach((a) => {
    const href = a.href;
    if (seen.has(href)) return;
    const card = a.closest("div.Nv2PK") || a.closest('[role="article"]') || a.parentElement;
    if (!card) return;
    const nome = clean(a.getAttribute("aria-label") || card.querySelector(".qBF1Pd, .fontHeadlineSmall")?.textContent);
    if (!nome) return;
    seen.add(href);
    const r = { nome, link: href, categoria: "", endereco: "", telefone: "", site: "", nota: "", avaliacoes: "" };

    r.nota = clean(card.querySelector("span.MW4etd")?.textContent);
    r.avaliacoes = clean(card.querySelector("span.UY7F9")?.textContent).replace(/[()\s.,]/g, "");
    if (!r.nota) {
      const star = card.querySelector('span[role="img"][aria-label]');
      const m = star && star.getAttribute("aria-label").match(/([\d.,]+)\s*(?:estrelas|stars|estrellas)/i);
      if (m) r.nota = m[1];
    }
    const phoneEl = card.querySelector("span.UsdlK");
    if (phoneEl) r.telefone = clean(phoneEl.textContent);

    const lines = card.innerText.split("\n").map(clean).filter(Boolean);
    if (!r.nota) {
      const rl = lines.find((l) => /^\d[.,]\d\s*\(\s*[\d.,]+\s*\)/.test(l));
      if (rl) { const m = rl.match(/^(\d[.,]\d)\s*\(\s*([\d.,]+)/); r.nota = m[1]; r.avaliacoes = r.avaliacoes || m[2].replace(/[.,]/g, ""); }
    }
    for (const line of lines.slice(1)) {
      if (!line.includes("·")) continue;
      const parts = line.split("·").map(clean).filter(Boolean);
      if (!parts.length) continue;
      if (HOURS.test(parts[0])) {
        if (!r.telefone) {
          const p = parts.slice(1).find((x) => PHONE.test(x) && x.replace(/\D/g, "").length >= 8);
          if (p) r.telefone = p.match(PHONE)[1].trim();
        }
        continue;
      }
      if (/^[\d.,]+\s*\(/.test(parts[0])) continue; // linha de nota
      if (!r.categoria) {
        r.categoria = parts[0];
        const rest = parts.slice(1).filter((x) => !/^[$€£R]?\$+|^R\$|^\$|^€|^£/.test(x) && !/^\d+\s*-\s*\d+/.test(x) && x !== "Acessível" && !HOURS.test(x));
        if (rest.length) r.endereco = rest[rest.length - 1];
      }
    }
    const site = card.querySelector('a[data-value="Website"], a[data-value="Site"], a.lcr4fd');
    if (site) r.site = site.href;
    const ll = href.match(/!3d(-?\d+\.\d+)!4d(-?\d+\.\d+)/);
    if (ll) { r.lat = ll[1]; r.lng = ll[2]; }
    out.push(r);
  });
  const feed = document.querySelector('div[role="feed"]');
  const end = !!document.querySelector("span.HlvSq") || (feed ? /chegou ao final da lista|reached the end of the list|llegado al final/i.test(feed.innerText.slice(-600)) : false);
  return { rows: out, hasFeed: !!feed, end, url: location.href };
}

function pageMapsScroll() {
  const feed = document.querySelector('div[role="feed"]');
  if (!feed) return { ok: false };
  feed.scrollBy(0, feed.scrollHeight);
  return { ok: true };
}

async function pageMapsDetail(href, nome) {
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const clean = (s) => String(s || "").replace(/[-]/g, "").replace(/\s+/g, " ").trim();
  const links = [...document.querySelectorAll('a[href*="/maps/place/"]')];
  const a = links.find((x) => x.href === href) || links.find((x) => clean(x.getAttribute("aria-label")) === nome);
  if (!a) return { ok: false, reason: "notfound" };
  a.scrollIntoView({ block: "center" });
  a.click();
  for (let i = 0; i < 30; i++) {
    await sleep(300);
    const mains = [...document.querySelectorAll('div[role="main"][aria-label]')];
    const main = mains.find((m) => clean(m.getAttribute("aria-label")) === nome);
    if (main && main.querySelector("[data-item-id]")) {
      await sleep(350);
      const telBtn = main.querySelector('button[data-item-id^="phone:tel:"], a[data-item-id^="phone:tel:"]');
      const telefone = telBtn ? telBtn.getAttribute("data-item-id").replace("phone:tel:", "") : "";
      let site = main.querySelector('a[data-item-id="authority"]')?.href || "";
      if (site.includes("/url?")) {
        try { site = new URL(site).searchParams.get("q") || site; } catch (_) {}
      }
      const endereco = clean((main.querySelector('button[data-item-id="address"]')?.getAttribute("aria-label") || "").replace(/^(Endereço|Address|Dirección)\s*:\s*/i, ""));
      const categoria = clean(main.querySelector("button.DkEaL")?.textContent);
      return { ok: true, telefone, site, endereco, categoria };
    }
  }
  return { ok: false, reason: "timeout" };
}

function pageGenericCollect() {
  const clean = (s) => String(s || "").replace(/\s+/g, " ").trim();
  const tables = [...document.querySelectorAll("table")].map((t) => ({ t, n: t.querySelectorAll("tr").length })).sort((a, b) => b.n - a.n);
  if (!tables.length || tables[0].n < 2) return { headers: [], rows: [] };
  const t = tables[0].t;
  let headerCells = [...t.querySelectorAll("thead th")];
  const trs = [...t.querySelectorAll("tr")];
  let bodyStart = 0;
  if (!headerCells.length) {
    headerCells = [...trs[0].querySelectorAll("th,td")];
    bodyStart = 1;
  }
  const headers = headerCells.map((c, i) => clean(c.innerText) || "Coluna " + (i + 1));
  const rows = [];
  for (const tr of trs.slice(bodyStart)) {
    if (tr.closest("thead")) continue;
    const cells = [...tr.querySelectorAll("td")];
    if (!cells.length) continue;
    rows.push(cells.map((c) => {
      const a = c.querySelector("a[href^='http'], a[href^='mailto:'], a[href^='tel:']");
      const txt = clean(c.innerText);
      return txt || (a ? a.href : "");
    }));
  }
  return { headers, rows };
}

function pageGenericScroll() {
  window.scrollTo(0, document.documentElement.scrollHeight);
  return { ok: true };
}

function pageGenericNext() {
  const cands = [
    ...document.querySelectorAll('a[rel="next"], button[rel="next"], a[aria-label*="next" i], a[aria-label*="próxim" i], button[aria-label*="next" i], button[aria-label*="próxim" i]'),
  ];
  if (!cands.length) {
    for (const el of document.querySelectorAll("a, button")) {
      const t = (el.innerText || "").trim();
      if (/^(próxima|proxima|próximo|proximo|next|seguinte|siguiente|›|»|>)$/i.test(t)) cands.push(el);
    }
  }
  const el = cands.find((e) => !e.disabled && e.getAttribute("aria-disabled") !== "true");
  if (!el) return { ok: false };
  el.click();
  return { ok: true };
}

async function run(func, args = []) {
  if (!state.tabId) throw new Error("Nenhuma aba conectada");
  const [res] = await chrome.scripting.executeScript({ target: { tabId: state.tabId }, func, args });
  return res ? res.result : null;
}

// ---------------------------------------------------------------------------
// Conexão com a aba
// ---------------------------------------------------------------------------
function setMode(mode, url) {
  state.mode = mode;
  const badge = $("modeBadge");
  if (mode === "maps") {
    badge.textContent = "🗺️ Google Maps conectado";
    badge.className = "mode-badge ok";
    $("btnOpenMaps").style.display = "none";
    $("mapsExtras").style.display = "";
    $("queuePanel").style.display = "";
    setStatus("Conectado ao Google Maps. Ative a rolagem automática pra coletar mais resultados.", "ok");
  } else if (mode === "generic") {
    let host = "";
    try { host = new URL(url).hostname; } catch (_) {}
    badge.textContent = "📄 Página genérica: " + host;
    badge.className = "mode-badge warn";
    $("btnOpenMaps").style.display = "";
    $("mapsExtras").style.display = "none";
    $("queuePanel").style.display = "";
    setStatus("Modo genérico: lendo a maior tabela da página. Pra empresas, o Google Maps é mais confiável.");
  } else {
    badge.textContent = "Aguardando aba...";
    badge.className = "mode-badge";
    $("btnOpenMaps").style.display = "";
    $("queuePanel").style.display = "";
    setStatus("Aguardando aba do Google Maps...");
  }
}

async function connectTab(tabId) {
  try {
    const tab = await chrome.tabs.get(tabId);
    if (!tab || !tab.url || tab.url.startsWith("chrome") || tab.url.startsWith(location.origin)) throw new Error("aba inválida");
    state.tabId = tab.id;
    setMode(/google\.[a-z.]+\/maps|maps\.google\./.test(tab.url) ? "maps" : "generic", tab.url);
    await collectOnce();
  } catch (e) {
    state.tabId = null;
    setMode(null);
  }
}

async function findCurrentTab() {
  const tabs = await chrome.tabs.query({});
  const cands = tabs
    .filter((t) => t.url && /^https?:/.test(t.url))
    .sort((a, b) => (b.lastAccessed || 0) - (a.lastAccessed || 0));
  return cands[0];
}
async function findMapsTab() {
  const tabs = await chrome.tabs.query({});
  return tabs
    .filter((t) => t.url && /google\.[a-z.]+\/maps/.test(t.url))
    .sort((a, b) => (b.lastAccessed || 0) - (a.lastAccessed || 0))[0];
}

// ---------------------------------------------------------------------------
// Coleta
// ---------------------------------------------------------------------------
async function collectOnce(extra = null) {
  if (!state.tabId) return 0;
  try {
    if (state.mode === "maps") {
      const res = await run(pageMapsCollect);
      if (!res) return 0;
      if (!state.columns.length || !state.columns.find((c) => c.key === "nome")) ensureColumns(MAPS_COLUMNS);
      const meta = extra || parseQuery(queryFromMapsUrl(res.url));
      const n = addRows(res.rows, { nicho: meta.nicho, cidade: meta.cidade });
      rerender();
      if (!res.hasFeed && !res.rows.length) setStatus("Faça uma busca no Google Maps (ex.: \"pizzaria em Curitiba\") pra aparecer a lista de resultados.");
      state.lastEnd = res.end;
      return n;
    } else {
      const res = await run(pageGenericCollect);
      if (!res || !res.headers.length) { setStatus("Nenhuma tabela encontrada nesta página."); return 0; }
      const keys = res.headers.map((h, i) => {
        const k = slug(h);
        const map = { nome: "nome", name: "nome", empresa: "nome", telefone: "telefone", phone: "telefone", fone: "telefone", email: "email", e_mail: "email", site: "site", website: "site", endereco: "endereco", address: "endereco", cidade: "cidade", city: "cidade" };
        return { key: map[k] || "c_" + k, label: h, i };
      });
      ensureColumns(keys.map(({ key, label }) => ({ key, label })));
      if (!state.columns.find((c) => c.key === "whatsapp") && keys.some((k) => k.key === "telefone")) ensureColumns([{ key: "whatsapp", label: "WhatsApp" }]);
      if (!state.columns.find((c) => c.key === "status")) ensureColumns([{ key: "status", label: "Status" }]);
      const rows = res.rows.map((cells) => {
        const r = { _cells: cells };
        keys.forEach(({ key, i }) => { r[key] = cells[i] ?? ""; });
        return r;
      });
      const n = addRows(rows, extra || {});
      rerender();
      return n;
    }
  } catch (e) {
    setStatus("Não consegui ler a aba: " + e.message + ". Clique em \"Usar aba atual\".", "err");
    return 0;
  }
}

function startTimer() {
  if (!state.startedAt) state.startedAt = Date.now();
  if (state.timer) return;
  state.timer = setInterval(() => {
    const s = Math.round((Date.now() - state.startedAt) / 1000);
    $("statTime").textContent = s < 60 ? s + "s" : Math.floor(s / 60) + "m " + (s % 60) + "s";
    if (!state.scrolling && !state.paginating && !state.enriching && !state.queueRunning) {
      clearInterval(state.timer);
      state.timer = null;
    }
  }, 1000);
}

async function scrollLoop() {
  if (state.scrolling) return;
  if (!state.tabId) { $("autoScroll").checked = false; setStatus("Conecte uma aba primeiro (\"Usar aba atual\").", "err"); return; }
  state.scrolling = true;
  startTimer();
  let semNovos = 0;
  while ($("autoScroll").checked && state.tabId) {
    try {
      await run(state.mode === "maps" ? pageMapsScroll : pageGenericScroll);
    } catch (_) {}
    state.scrolls++;
    $("statScrolls").textContent = state.scrolls;
    await sleep(randDelay());
    const n = await collectOnce();
    setStatus(`Rolando... +${n} novas nesta rolagem (${state.rows.length} no total).`, "ok");
    semNovos = n ? 0 : semNovos + 1;
    if (state.mode === "maps" && (state.lastEnd || semNovos >= 4)) {
      setStatus(`Fim da lista: ${state.rows.length} empresas coletadas.`, "ok");
      break;
    }
    if (state.mode !== "maps" && semNovos >= 3) {
      if ($("autoPaginate").checked) break;
      setStatus("Nada novo apareceu após 3 rolagens. Rolagem pausada.");
      break;
    }
  }
  $("autoScroll").checked = false;
  state.scrolling = false;
  if (state.mode === "maps" && $("autoComplete").checked && !state.queueRunning) await enrichAll();
  if ($("autoPaginate").checked && state.mode !== "maps") paginateLoop();
}

async function paginateLoop() {
  if (state.paginating) return;
  if (!state.tabId) { $("autoPaginate").checked = false; return; }
  if (state.mode === "maps") {
    toast("No Google Maps a lista é contínua — use a rolagem automática.");
    $("autoPaginate").checked = false;
    return;
  }
  state.paginating = true;
  startTimer();
  let pages = 0;
  while ($("autoPaginate").checked && state.tabId) {
    const r = await run(pageGenericNext).catch(() => null);
    if (!r || !r.ok) { setStatus(`Não achei botão de próxima página. ${pages} páginas lidas.`); break; }
    pages++;
    await waitTabLoaded(state.tabId);
    await sleep(randDelay());
    const n = await collectOnce();
    setStatus(`Página ${pages + 1}: +${n} linhas (${state.rows.length} no total).`, "ok");
  }
  $("autoPaginate").checked = false;
  state.paginating = false;
}

function waitTabLoaded(tabId, timeout = 20000) {
  return new Promise((resolve) => {
    const t0 = Date.now();
    const check = async () => {
      try {
        const t = await chrome.tabs.get(tabId);
        if (t.status === "complete" || Date.now() - t0 > timeout) return resolve();
      } catch (_) { return resolve(); }
      setTimeout(check, 400);
    };
    setTimeout(check, 600);
  });
}

// ---------------------------------------------------------------------------
// Enriquecimento: telefone/site (Maps) e emails (sites)
// ---------------------------------------------------------------------------
async function enrichDetails(onlyRows = null) {
  if (state.mode !== "maps" || !state.tabId) { setStatus("Telefone/site só pode ser completado com uma aba do Google Maps conectada.", "err"); return; }
  const list = (onlyRows || state.rows).filter((r) => r.link && !r._det && (!r.telefone || !r.site));
  if (!list.length) { setStatus("Todas as empresas já foram verificadas para telefone/site.", "ok"); return; }
  state.enriching = true;
  startTimer();
  let done = 0, achados = 0;
  for (const r of list) {
    if (state.queueStop) break;
    setStatus(`Buscando telefone/site: ${r.nome} (${done + 1}/${list.length})`);
    progress(done, list.length);
    try {
      const d = await run(pageMapsDetail, [r.link, r.nome]);
      if (d && d.ok) {
        if (d.telefone && !r.telefone) { r.telefone = d.telefone; achados++; }
        if (d.site && !r.site) r.site = d.site;
        if (d.endereco && (!r.endereco || r.endereco.length < d.endereco.length)) r.endereco = d.endereco;
        if (d.categoria && !r.categoria) r.categoria = d.categoria;
        r._det = 1;
      } else if (d && d.reason === "timeout") {
        r._det = 1;
      }
    } catch (_) {}
    done++;
    if (done % 3 === 0) rerender();
    await sleep(Math.min(randDelay(), 2500));
  }
  progress(0, 0);
  state.enriching = false;
  rerender();
  setStatus(`Telefone/site: ${done} verificadas, ${achados} telefones novos.`, "ok");
}

const BAD_EMAIL = /(\.(png|jpe?g|gif|webp|svg|css|js)$)|example\.|exemplo\.|sentry|wixpress|@domain|@email\.|seuemail|youremail|noreply|no-reply|godaddy|\.wix\.com/i;
async function fetchText(url, ms = 8000) {
  const ctrl = new AbortController();
  const to = setTimeout(() => ctrl.abort(), ms);
  try {
    const r = await fetch(url, { signal: ctrl.signal, redirect: "follow", credentials: "omit" });
    if (!r.ok) return "";
    const type = r.headers.get("content-type") || "";
    if (!type.includes("text") && !type.includes("html")) return "";
    return (await r.text()).slice(0, 600000);
  } catch (_) {
    return "";
  } finally {
    clearTimeout(to);
  }
}
function extractEmails(html) {
  const set = new Set();
  const decoded = html.replace(/&#64;|&#x40;|\[at\]|\(at\)/gi, "@").replace(/%40/g, "@");
  for (const m of decoded.matchAll(/mailto:([^"'?>\s]+)/gi)) set.add(m[1].toLowerCase());
  for (const m of decoded.matchAll(/[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}/g)) set.add(m[0].toLowerCase());
  return [...set].filter((e) => !BAD_EMAIL.test(e) && e.length < 80);
}
async function findEmails(site) {
  let base;
  try { base = new URL(site.startsWith("http") ? site : "https://" + site); } catch (_) { return []; }
  if (/instagram\.com|facebook\.com|wa\.me|whatsapp|linktr\.ee|google\./i.test(base.hostname)) return [];
  let emails = extractEmails(await fetchText(base.href));
  if (!emails.length) {
    for (const p of ["/contato", "/contact", "/fale-conosco", "/contatos", "/sobre"]) {
      emails = extractEmails(await fetchText(new URL(p, base.origin).href, 6000));
      if (emails.length) break;
    }
  }
  return emails.slice(0, 3);
}
async function enrichEmails(onlyRows = null) {
  const list = (onlyRows || state.rows).filter((r) => r.site && !r.email && !r._em);
  if (!list.length) { setStatus("Nenhum site novo pra procurar email.", "ok"); return; }
  state.enriching = true;
  startTimer();
  let done = 0, achados = 0;
  const queue = [...list];
  const worker = async () => {
    while (queue.length && !state.queueStop) {
      const r = queue.shift();
      const em = await findEmails(r.site);
      if (em.length) { r.email = em.join(", "); achados++; }
      r._em = 1;
      done++;
      progress(done, list.length);
      setStatus(`Procurando emails nos sites: ${done}/${list.length} (${achados} encontrados)`);
      if (done % 4 === 0) rerender();
    }
  };
  await Promise.all([worker(), worker(), worker()]);
  progress(0, 0);
  state.enriching = false;
  rerender();
  setStatus(`Emails: ${achados} encontrados em ${done} sites.`, "ok");
}
async function enrichAll(rows = null) {
  await enrichDetails(rows);
  await enrichEmails(rows);
}

// ---------------------------------------------------------------------------
// Fila de buscas
// ---------------------------------------------------------------------------
async function runQueue() {
  const lines = $("queueInput").value.split("\n").map((s) => s.trim()).filter(Boolean);
  if (!lines.length) { toast("Escreva pelo menos uma busca, uma por linha."); return; }
  state.queueRunning = true;
  state.queueStop = false;
  $("btnQueueStart").style.display = "none";
  $("btnQueueStop").style.display = "";
  startTimer();
  const scrollsPer = Math.max(1, Number($("queueScrolls").value) || 6);
  const log = [];
  for (let qi = 0; qi < lines.length && !state.queueStop; qi++) {
    const q = lines[qi];
    const meta = parseQuery(q);
    $("queueStatus").textContent = log.concat(`⏳ ${qi + 1}/${lines.length} — ${q}`).join("\n");
    const url = "https://www.google.com/maps/search/" + encodeURIComponent(q).replace(/%20/g, "+");
    try {
      if (state.tabId) {
        await chrome.tabs.update(state.tabId, { url });
      } else {
        const t = await chrome.tabs.create({ url, active: false });
        state.tabId = t.id;
      }
    } catch (_) {
      const t = await chrome.tabs.create({ url, active: false });
      state.tabId = t.id;
    }
    setMode("maps");
    await waitTabLoaded(state.tabId);
    // espera a lista aparecer
    for (let i = 0; i < 20; i++) {
      await sleep(700);
      const ok = await run(() => !!document.querySelector('div[role="feed"]') || !!document.querySelector('div[role="main"][aria-label]')).catch(() => false);
      if (ok) break;
    }
    const before = state.rows.length;
    await collectOnce(meta);
    for (let s = 0; s < scrollsPer && !state.queueStop; s++) {
      await run(pageMapsScroll).catch(() => null);
      state.scrolls++;
      await sleep(randDelay());
      await collectOnce(meta);
      if (state.lastEnd) break;
    }
    const novos = state.rows.slice(before);
    if ($("autoComplete").checked && novos.length && !state.queueStop) await enrichAll(novos);
    log.push(`✅ ${q}: ${novos.length} empresas`);
    $("queueStatus").textContent = log.join("\n");
  }
  if (state.queueStop) log.push("⏹ Fila interrompida.");
  $("queueStatus").textContent = log.join("\n");
  state.queueRunning = false;
  state.queueStop = false;
  $("btnQueueStart").style.display = "";
  $("btnQueueStop").style.display = "none";
  setStatus(`Fila concluída. ${state.rows.length} empresas no total.`, "ok");
}

// ---------------------------------------------------------------------------
// Exportação
// ---------------------------------------------------------------------------
function exportMatrix() {
  const cols = visibleColumns();
  const rows = filteredRows();
  return [cols.map((c) => c.label), ...rows.map((r) => cols.map((c) => {
    const v = cellValue(r, c.key);
    if ((c.key === "nota") && v !== "" && !isNaN(Number(String(v).replace(",", ".")))) return Number(String(v).replace(",", "."));
    if ((c.key === "avaliacoes") && /^\d+$/.test(String(v))) return Number(v);
    return v;
  }))];
}
function download(blob, name) {
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = name;
  document.body.appendChild(a);
  a.click();
  setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 1000);
}
function fileStamp() {
  const d = new Date();
  const p = (n) => String(n).padStart(2, "0");
  return `primoris-empresas-${d.getFullYear()}${p(d.getMonth() + 1)}${p(d.getDate())}-${p(d.getHours())}${p(d.getMinutes())}`;
}
function exportCsv() {
  const m = exportMatrix();
  if (m.length < 2) return toast("Nada pra exportar.");
  const csv = m.map((r) => r.map((v) => {
    const s = String(v ?? "");
    return /[";\n\r]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s;
  }).join(";")).join("\r\n");
  download(new Blob(["﻿" + csv], { type: "text/csv;charset=utf-8" }), fileStamp() + ".csv");
}
function exportXlsx() {
  const m = exportMatrix();
  if (m.length < 2) return toast("Nada pra exportar.");
  download(XlsxLite.build(m, "Empresas"), fileStamp() + ".xlsx");
}
async function copyAll() {
  const m = exportMatrix();
  if (m.length < 2) return toast("Nada pra copiar.");
  const tsv = m.map((r) => r.map((v) => String(v ?? "").replace(/[\t\n\r]+/g, " ")).join("\t")).join("\n");
  try {
    await navigator.clipboard.writeText(tsv);
    toast(`${m.length - 1} linhas copiadas — cole no Excel ou Google Sheets.`);
  } catch (_) {
    toast("Não consegui copiar. Tente exportar CSV.");
  }
}

// ---------------------------------------------------------------------------
// Modo foco
// ---------------------------------------------------------------------------
function openFocus() {
  state.focus.list = filteredRows().filter((r) => waNumber(r));
  state.focus.i = Math.max(0, state.focus.list.findIndex((r) => (r.status || "Novo") === "Novo"));
  $("focusOverlay").style.display = "";
  renderFocus();
}
function closeFocus() {
  $("focusOverlay").style.display = "none";
  rerender();
}
function renderFocus() {
  const { list, i } = state.focus;
  const empty = !list.length;
  $("focusEmpty").style.display = empty ? "" : "none";
  $("focusCard").style.display = empty ? "none" : "";
  $("focusOpenWa").style.visibility = empty ? "hidden" : "";
  $("focusCount").textContent = empty ? "0 de 0" : `${i + 1} de ${list.length}`;
  $("focusProgressBar").style.width = empty ? "0" : Math.round(((i + 1) / list.length) * 100) + "%";
  if (empty) return;
  const r = list[i];
  $("focusNome").textContent = r.nome || "(sem nome)";
  $("focusMeta").textContent = [r.categoria, r.cidade, r.telefone, "Status: " + (r.status || "Novo")].filter(Boolean).join(" · ");
  const msg = fillTemplate(r);
  $("focusMsg").textContent = msg || "(sem mensagem — escreva o texto no campo \"Mensagem WhatsApp\")";
  $("focusOpenWa").href = waLink(r);
  $("focusPrev").disabled = i === 0;
  $("focusNext").textContent = i === list.length - 1 ? "Concluir ✓" : "Próximo →";
}
function focusNext() {
  const { list } = state.focus;
  if (!list.length) return;
  const r = list[state.focus.i];
  if ($("focusAutoStatus").checked && (r.status || "Novo") === "Novo") r.status = "Contatado";
  save();
  if (state.focus.i >= list.length - 1) { closeFocus(); toast("Lista concluída 🎉"); return; }
  state.focus.i++;
  renderFocus();
}
function focusPrev() {
  if (state.focus.i > 0) { state.focus.i--; renderFocus(); }
}

// ---------------------------------------------------------------------------
// Eventos
// ---------------------------------------------------------------------------
function bind() {
  $("btnReconnect").addEventListener("click", async () => {
    const t = await findCurrentTab();
    if (!t) return setStatus("Nenhuma aba aberta. Abra o Google Maps e faça uma busca.", "err");
    await connectTab(t.id);
  });
  $("btnOpenMaps").addEventListener("click", async () => {
    const t = await chrome.tabs.create({ url: "https://www.google.com/maps", active: true });
    state.tabId = t.id;
    setMode("maps");
    setStatus("Faça sua busca no Maps (ex.: \"dentista em Belo Horizonte\") e volte aqui — clique em \"Usar aba atual\".");
  });
  $("autoScroll").addEventListener("change", () => { if ($("autoScroll").checked) scrollLoop(); });
  $("autoPaginate").addEventListener("change", () => { if ($("autoPaginate").checked && !state.scrolling) paginateLoop(); });
  ["minDelay", "maxDelay", "queueInput", "queueScrolls"].forEach((id) => $(id).addEventListener("change", save));
  $("autoComplete").addEventListener("change", save);
  $("focusAutoStatus").addEventListener("change", save);
  $("msgTemplate").addEventListener("input", () => { save(); clearTimeout(state.tplT); state.tplT = setTimeout(renderTable, 400); });

  $("btnDetails").addEventListener("click", () => enrichDetails());
  $("btnEmails").addEventListener("click", () => enrichEmails());
  $("btnQueueStart").addEventListener("click", runQueue);
  $("btnQueueStop").addEventListener("click", () => { state.queueStop = true; $("queueStatus").textContent += "\nParando após a etapa atual..."; });

  ["filterStatus", "filterNicho", "filterCidade"].forEach((id) => $(id).addEventListener("change", renderTable));
  document.querySelectorAll(".country-tab").forEach((b) => b.addEventListener("click", () => {
    document.querySelectorAll(".country-tab").forEach((x) => x.classList.remove("active"));
    b.classList.add("active");
    state.country = b.dataset.filter;
    renderTable();
  }));

  $("tbody").addEventListener("change", (e) => {
    const id = e.target.getAttribute("data-status");
    if (!id) return;
    const r = state.rows.find((x) => x._id === id);
    if (r) { r.status = e.target.value; refreshFilters(); save(); }
  });

  $("btnExportCsv").addEventListener("click", exportCsv);
  $("btnExportXlsx").addEventListener("click", exportXlsx);
  $("btnCopyAll").addEventListener("click", copyAll);
  $("btnClear").addEventListener("click", () => {
    if (!confirm("Apagar todas as empresas coletadas? Isso não pode ser desfeito.")) return;
    state.rows = [];
    state.columns = state.mode === "maps" ? MAPS_COLUMNS.map((c) => ({ ...c, visible: true })) : [];
    state.scrolls = 0;
    state.startedAt = null;
    $("statTime").textContent = "0s";
    renderColumnManager();
    rerender();
    setStatus("Lista limpa.");
  });

  $("btnFocusMode").addEventListener("click", openFocus);
  $("focusClose").addEventListener("click", closeFocus);
  $("focusNext").addEventListener("click", focusNext);
  $("focusPrev").addEventListener("click", focusPrev);
  $("focusOpenWa").addEventListener("click", (e) => { if (!$("focusOpenWa").href || $("focusOpenWa").getAttribute("href") === "#") e.preventDefault(); });
  document.addEventListener("keydown", (e) => {
    if ($("focusOverlay").style.display === "none") return;
    if (e.target.tagName === "INPUT" && e.target.type === "text") return;
    if (e.key === "Escape") closeFocus();
    else if (e.key === "Enter" || e.key === "ArrowRight") { e.preventDefault(); focusNext(); }
    else if (e.key === "ArrowLeft") { e.preventDefault(); focusPrev(); }
  });

  chrome.runtime.onMessage.addListener((msg) => {
    if (msg && msg.type === "primoris:setTab" && msg.tabId) connectTab(msg.tabId);
  });
  chrome.tabs.onRemoved.addListener((id) => {
    if (id === state.tabId) {
      state.tabId = null;
      $("autoScroll").checked = false;
      $("autoPaginate").checked = false;
      setMode(null);
    }
  });
}

// ---------------------------------------------------------------------------
// Início
// ---------------------------------------------------------------------------
(async function init() {
  bind();
  await load();
  if (!state.columns.length && state.rows.length) ensureColumns(MAPS_COLUMNS);
  renderColumnManager();
  rerender();
  const param = new URLSearchParams(location.search).get("tab");
  if (param) await connectTab(Number(param));
  else {
    const t = await findMapsTab();
    if (t) await connectTab(t.id);
    else setMode(null);
  }
})();
